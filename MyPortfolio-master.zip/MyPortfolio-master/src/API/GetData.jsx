import data from "./data.json";

function getData() {
  return data;
}

export default getData;
